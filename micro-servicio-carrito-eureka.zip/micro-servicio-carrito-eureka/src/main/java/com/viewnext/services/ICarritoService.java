package com.viewnext.services;

import com.viewnext.models.Carrito;

public interface ICarritoService {
	
	public Carrito crear(String usuario);
	
	public Carrito consultar(String usuario);
	
	public Carrito agregarPedido(Long id, int cantidad, String usuario);
	
	public Carrito sacarPedido(Long id, String usuario);

}
