package com.viewnext.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.clients.PedidosClienteFeign;
import com.viewnext.models.Carrito;
import com.viewnext.models.Pedido;
import com.viewnext.persistence.CarritosDAO;

@Service
public class CarritoServiceImpl implements ICarritoService{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = new Carrito();
		carrito.setUsuario(usuario);
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito agregarPedido(Long id, int cantidad, String usuario) {
		Pedido pedido = clienteFeign.crearPedido(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importe = carrito.getImporte() + (pedido.getProducto().getPrecio() * cantidad);
		carrito.setImporte(importe);
		return dao.save(carrito);
	}

	@Override
	public Carrito sacarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		Pedido encontrado = null;
		for (Pedido pedido : contenido) {
			if (id == pedido.getProducto().getID()) {
				encontrado = pedido;
				break;
			}
		}
		
		contenido.remove(encontrado);
		double importe = carrito.getImporte() - 
				(encontrado.getProducto().getPrecio() * encontrado.getCantidad());
		carrito.setImporte(importe);
		
		return dao.save(carrito);
	}

}












