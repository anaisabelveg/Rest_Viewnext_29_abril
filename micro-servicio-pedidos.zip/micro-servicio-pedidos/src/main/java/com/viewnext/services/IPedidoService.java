package com.viewnext.services;

import com.viewnext.models.Pedido;

public interface IPedidoService {
	
	Pedido crearPedido(Long id, int cantidad);

}
