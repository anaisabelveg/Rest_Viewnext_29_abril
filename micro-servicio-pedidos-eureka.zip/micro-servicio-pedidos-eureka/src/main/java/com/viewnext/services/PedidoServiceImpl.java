package com.viewnext.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.clients.ProductosClienteFeign;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
public class PedidoServiceImpl implements IPedidoService{
	
	@Autowired
	private ProductosClienteFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Lanzar una peticion al micro-servicio-productos para obtener el producto
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}

}
